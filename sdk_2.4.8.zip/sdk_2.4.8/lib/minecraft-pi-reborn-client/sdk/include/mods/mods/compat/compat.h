#pragma once

#ifdef __cplusplus
extern "C" {
#endif

int compat_check_exit_requested();
void compat_request_exit();

#ifdef __cplusplus
}
#endif
