#pragma once

#ifdef __cplusplus
extern "C" {
#endif

char *version_get();

#ifdef __cplusplus
}
#endif
