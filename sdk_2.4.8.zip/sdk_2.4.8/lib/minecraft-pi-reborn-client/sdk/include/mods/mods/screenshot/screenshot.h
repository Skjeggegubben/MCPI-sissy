#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void screenshot_take(char *home);

#ifdef __cplusplus
}
#endif
