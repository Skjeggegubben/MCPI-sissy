#pragma once

/* #undef MCPI_SERVER_MODE */
/* #undef MCPI_HEADLESS_MODE */
#define MCPI_IS_APPIMAGE_BUILD
#define MCPI_USE_PREBUILT_ARMHF_TOOLCHAIN
#define MCPI_USE_GLES1_COMPATIBILITY_LAYER
#define MCPI_APP_BASE_TITLE "Minecraft: Pi Edition: Reborn"
#define MCPI_APP_TITLE "Minecraft: Pi Edition: Reborn (Client)"
#define MCPI_APP_ID "com.thebrokenrail.MCPIRebornClient"
#define MCPI_VERSION "2.4.8"
#define MCPI_VARIANT_NAME "minecraft-pi-reborn-client"
#define MCPI_SDK_DIR "lib/minecraft-pi-reborn-client/sdk"
